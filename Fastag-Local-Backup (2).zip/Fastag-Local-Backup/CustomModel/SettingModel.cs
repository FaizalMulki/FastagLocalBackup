﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OrchestratorAsset.Web.CustomModel
{
    public class SettingModel
    {
        public int Id { get; set; }
        public DateTime EffectiveFrom { get; set; }
        public DateTime EffectiveTo { get; set; }
        public int VehicleTypeId { get; set; }
        public decimal RefundableSecurityDeposit { get; set; }
        public decimal FastagFee { get; set; }
        public decimal MinimumBalanceWalletDeposit { get; set; }
        public decimal Others { get; set; }
    }

    public class VehicleTypeModel
    {
        public int Id { get; set; }
        public string Type { get; set; }
    }



}