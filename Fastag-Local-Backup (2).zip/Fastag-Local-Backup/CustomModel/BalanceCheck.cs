﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Serialization;

namespace OrchestratorAsset.Web.CustomModel
{
    public class BalanceCheck
    {
        [XmlRoot(Namespace = "http://www.finacle.com/fixml", ElementName = "FIXML", DataType = "string", IsNullable = true)]
        public class FIXML
        {
            public FIXMLHeader Header { get; set; }
            public FIXMLBody Body { get; set; }
        }

        public class FIXMLHeader
        {
            public ResponseHeader ResponseHeader { get; set; }
        }
        public class ResponseHeader
        {

            public HostTransaction HostTransaction { get; set; }

        }
        public class HostTransaction
        {
            public string Status { get; set; }

        }


        public class FIXMLBody
        {
            public BalInqResponse BalInqResponse { get; set; }
        }


        public class BalInqResponse
        {
            public BalInqRs BalInqRs { get; set; }
        }

        public class BalInqRs
        {
            [XmlElement("AcctBal")]
            public List<AcctBal> AcctBalItems { get; set; }
        }

        public class AcctBal
        {
            public string BalType { get; set; }
            public BalAmt BalAmt { get; set; }
        }

        public class BalAmt
        {
            public decimal amountValue { get; set; }
        }
    }


}