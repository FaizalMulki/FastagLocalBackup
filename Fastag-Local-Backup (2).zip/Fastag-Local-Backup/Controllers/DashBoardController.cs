﻿using MySql.Data.MySqlClient;
using OrchestratorAsset.Web.DAL;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OrchestratorAsset.Web.Controllers
{
    public class DashBoardController : Controller
    {
        // GET: DashBoard
        public ActionResult Index()
        {
            return View();
        }

        public string Connection()
        {
            string connectionString = (ConfigurationManager.ConnectionStrings[2]).ConnectionString;
            return connectionString;
        }
        public object GetDashBoardHeader()
        {
            using (MySqlConnection connection = new MySqlConnection(Connection()))
            {
                try
                {
                    MySqlCommand cmd = new MySqlCommand("GetDashBoardCount", connection);
                    //cmd.Parameters.AddWithValue("IsSuperAdmin", Session["IsSuperAdmin"].ToString());
                    //cmd.Parameters.AddWithValue("CreatedBy", Session["FullName"].ToString());
                    cmd.CommandType = CommandType.StoredProcedure;
                    using (MySqlDataAdapter sda = new MySqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        sda.Fill(dt);
                        List<DashBoardHeader> header = new List<DashBoardHeader>();
                        header = CommonMethod.ConvertToList<DashBoardHeader>(dt);
                        return Json(header, JsonRequestBehavior.AllowGet);
                    }

                }
                catch (Exception e)
                {


                }
            }

            return null;
        }


    }

    public class DashBoardHeader
    {
        public long TotalReg { get; set; }
        public decimal TotalAmount { get; set; }
    }
}